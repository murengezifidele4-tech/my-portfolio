import { useState, useEffect, useRef } from 'react'
import heroPhoto from '@/imports/pro_14.jpg'
import imgDrums from '@/imports/GAD00946.jpg'
import imgPiano from '@/imports/pro_13__1_.jpg'
import imgStudio from '@/imports/ChatGPT_Image_Aug_7__2026__01_30_03_PM.png'
import imgLive from '@/imports/Pictures_6.JPG'
import imgPortrait from '@/imports/pro_12.jpg'

// ─── Nav ─────────────────────────────────────────────────────────────────────
function Nav() {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])
  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[#050505]/95 border-b border-red-900/30 backdrop-blur-sm' : 'bg-transparent'}`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-5 flex items-center justify-between">
        <div>
          <p className="text-red-500 text-[10px] tracking-[0.3em] uppercase" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
            Drummer · Pianist
          </p>
          <p className="text-red-500 text-[10px] tracking-[0.3em] uppercase" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
            Music Producer
          </p>
        </div>
        <div className="hidden md:flex items-center gap-8">
          {['Projects', 'Skills', 'Process', 'Contact'].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-xs tracking-[0.2em] uppercase text-zinc-400 hover:text-white transition-colors"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
            >
              {item}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-[10px] tracking-[0.2em] uppercase text-red-400" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
            Available for Performances
          </span>
        </div>
      </div>
    </nav>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#050505]">
      {/* Giant background text */}
      <div
        className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden"
        aria-hidden="true"
      >
        <span
          style={{
            fontFamily: 'Rajdhani, Bebas Neue, Impact, sans-serif',
            fontSize: 'clamp(120px, 22vw, 300px)',
            lineHeight: 1,
            color: 'transparent',
            WebkitTextStroke: '1px rgba(153,27,27,0.25)',
            letterSpacing: '-0.02em',
            background: 'linear-gradient(180deg, rgba(153,27,27,0.35) 0%, rgba(153,27,27,0.05) 100%)',
            WebkitBackgroundClip: 'text',
            backgroundClip: 'text',
          }}
        >
          FIDELE
        </span>
      </div>

      {/* Dark overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/70 to-transparent pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-[#050505]/60 pointer-events-none" />

      {/* Hero image — right side */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 md:w-[45%]">
        <img
          src={heroPhoto}
          alt="Fidele Murengezi performing on stage"
          className="w-full h-full object-cover"
          style={{ maskImage: 'linear-gradient(to right, transparent, black 30%, black 80%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 30%, black 80%, transparent)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent via-[#050505]/40 to-[#050505]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/50 via-transparent to-[#050505]/80" />
        {/* Red color overlay */}
        <div className="absolute inset-0 bg-red-900/10 mix-blend-multiply" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 pt-28 pb-16">
        <div className="max-w-2xl">
          <p
            className="text-zinc-400 text-sm mb-4"
            style={{ fontFamily: 'Rajdhani, Inter, sans-serif', letterSpacing: '0.05em' }}
          >
            Hello, I'm
          </p>
          <h1
            style={{
              fontFamily: 'Rajdhani, League Spartan, Arial Black, sans-serif',
              fontSize: 'clamp(52px, 8vw, 96px)',
              lineHeight: 0.95,
              fontWeight: 700,
              letterSpacing: '-0.02em',
            }}
            className="text-white mb-4"
          >
            Fidele<br />
            <span className="text-red-500">MURENGEZI</span>
          </h1>
          <p
            className="text-red-400 text-sm tracking-[0.3em] uppercase mb-6"
            style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
          >
            Drummer · Pianist · Music Producer · Drum Instructor
          </p>
          <p
            className="text-zinc-400 text-base leading-relaxed max-w-lg mb-10"
            style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
          >
            Creating immersive musical experiences through live performances, electronic music, music production, and visual storytelling.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-3 mb-14">
            <PrimaryBtn href="#projects">Watch Live Performances</PrimaryBtn>
            <SecondaryBtn href="#projects">Listen to Productions</SecondaryBtn>
            <GhostBtn href="#projects">View Projects</GhostBtn>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-8 border-t border-zinc-800/60 pt-8">
            {[
              ['50+', 'Live Performances'],
              ['20+', 'Students Taught'],
              ['15+', 'Creative Projects'],
            ].map(([num, label]) => (
              <div key={label}>
                <div
                  className="text-white"
                  style={{ fontFamily: 'Rajdhani, Bebas Neue, Impact, sans-serif', fontSize: 'clamp(36px, 5vw, 52px)', lineHeight: 1, color: '#ef4444' }}
                >
                  {num}
                </div>
                <div
                  className="text-zinc-500 text-[10px] tracking-[0.25em] uppercase mt-1"
                  style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                >
                  {label}
                </div>
              </div>
            ))}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                <span
                  className="text-zinc-400 text-xs tracking-widest uppercase"
                  style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                >
                  Available Worldwide
                </span>
              </div>
              <div
                className="text-zinc-600 text-[10px] tracking-widest uppercase"
                style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
              >
                Kigali, Rwanda
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Projects ─────────────────────────────────────────────────────────────────
const projects = [
  { num: '01', title: 'Live Drum Performances', category: 'Professional Performances', img: imgDrums, alt: 'Fidele performing drums on stage' },
  { num: '02', title: 'Live Piano Performances', category: 'Music Live Performances', img: imgPiano, alt: 'Fidele playing piano on stage' },
  { num: '03', title: 'Music Production', category: 'Original Music & Beats', img: imgStudio, alt: 'Music production studio' },
  { num: '04', title: 'Concert & Live Shows', category: 'Live Events & Performances', img: imgLive, alt: 'Live concert performance' },
]

function ProjectCard({ num, title, category, img, alt }: (typeof projects)[0]) {
  const [hovered, setHovered] = useState(false)
  return (
    <div
      className="group relative overflow-hidden cursor-pointer border border-zinc-800/60 hover:border-red-900/60 transition-all duration-500"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="relative overflow-hidden aspect-[4/3]">
        <img
          src={img}
          alt={alt}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/30 to-transparent" />
        {hovered && (
          <div className="absolute inset-0 bg-red-900/20 transition-opacity duration-300" />
        )}
        {/* Arrow button */}
        <div
          className={`absolute top-4 right-4 w-10 h-10 border border-white/30 flex items-center justify-center transition-all duration-300 ${hovered ? 'bg-red-600 border-red-600 scale-110' : 'bg-black/40'}`}
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 12L12 2M12 2H4M12 2V10" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <div className="p-5 bg-[#0a0a0a]">
        <div className="flex items-center justify-between">
          <div>
            <span
              className="text-red-500 text-xs tracking-widest"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
            >
              {num}
            </span>
            <h3
              className="text-white font-bold mt-1 group-hover:text-red-400 transition-colors"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: '1.05rem' }}
            >
              {title}
            </h3>
            <p
              className="text-zinc-500 text-xs mt-1 tracking-wide"
              style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
            >
              {category}
            </p>
          </div>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" className="text-zinc-600 group-hover:text-red-500 transition-colors shrink-0">
            <path d="M4 16L16 4M16 4H6M16 4V14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
    </div>
  )
}

function Projects() {
  return (
    <section id="projects" className="bg-[#050505] py-24 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="flex items-end justify-between mb-12">
          <div>
            <p className="text-red-500 text-xs tracking-widest uppercase mb-3" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
              Work
            </p>
            <h2
              className="text-white"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: 'clamp(32px, 5vw, 52px)', fontWeight: 700, letterSpacing: '-0.02em' }}
            >
              SELECTED PROJECTS
            </h2>
          </div>
          <SecondaryBtn href="#">View All Projects →</SecondaryBtn>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {projects.map((p) => <ProjectCard key={p.num} {...p} />)}
        </div>
        {/* Quick action buttons */}
        <div className="flex flex-wrap gap-3 mt-10 pt-10 border-t border-zinc-900">
          <PrimaryBtn href="#">Book a Drum Lesson</PrimaryBtn>
          <PrimaryBtn href="#">Book a Piano Lesson</PrimaryBtn>
          <GhostBtn href="#">Download Resume</GhostBtn>
        </div>
      </div>
    </section>
  )
}

// ─── Education & Skills ────────────────────────────────────────────────────────
const skills = [
  'Drumming', 'Piano', 'Music Production', 'FL Studio',
  'Ableton Live', 'Live Performance', 'Beat Making',
  'Mixing & Mastering', 'Event Performance', 'Drum Instruction',
  'Piano Instruction', 'Rhythm & Percussion', 'Creative Direction',
  'Arrangement', 'Sound Design',
]

function SkillsSection() {
  return (
    <section id="skills" className="bg-[#050505] py-24 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-2 gap-16">
          {/* Education */}
          <div>
            <p className="text-red-500 text-xs tracking-widest uppercase mb-8" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
              Education
            </p>
            <h2
              className="text-white mb-10"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700, letterSpacing: '-0.02em' }}
            >
              EDUCATION<br />&amp; SKILLS
            </h2>

            <div className="space-y-6">
              <div className="border-l-2 border-red-700 pl-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3
                      className="text-white font-semibold"
                      style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                    >
                      Professional Drummer
                    </h3>
                    <p
                      className="text-zinc-500 text-sm mt-0.5"
                      style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                    >
                      Rhythm & Percussion · Live Performances
                    </p>
                  </div>
                  <span
                    className="text-red-500 text-xs font-mono shrink-0"
                    style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                  >
                    Active
                  </span>
                </div>
              </div>
              <div className="border-l-2 border-zinc-800 pl-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3
                      className="text-white font-semibold"
                      style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                    >
                      Pianist & Keyboardist
                    </h3>
                    <p
                      className="text-zinc-500 text-sm mt-0.5"
                      style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                    >
                      Classical & Contemporary Piano Performance
                    </p>
                  </div>
                </div>
              </div>
              <div className="border-l-2 border-zinc-800 pl-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3
                      className="text-white font-semibold"
                      style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                    >
                      Music Production
                    </h3>
                    <p
                      className="text-zinc-500 text-sm mt-0.5"
                      style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                    >
                      FL Studio · Ableton Live · Beat Making
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Skills */}
          <div>
            <p
              className="text-red-500 text-xs tracking-widest uppercase mb-8"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
            >
              Skills
            </p>
            <div className="flex flex-wrap gap-2 mt-12">
              {skills.map((s) => (
                <span
                  key={s}
                  className="px-4 py-2 border border-zinc-800 text-zinc-300 text-xs tracking-wider hover:border-red-700/60 hover:text-white hover:bg-red-950/30 transition-all cursor-default"
                  style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Work Process ─────────────────────────────────────────────────────────────
const steps = [
  { num: '01', icon: '◎', title: 'DISCOVER', desc: 'Understanding client requirements, event goals, and project vision.' },
  { num: '02', icon: '◈', title: 'PLAN', desc: 'Performance planning, setlist curation, and music preparation.' },
  { num: '03', icon: '✦', title: 'CREATE', desc: 'Practice, production, and creative development tailored to the project.' },
  { num: '04', icon: '⟨/⟩', title: 'PERFORM', desc: 'Deliver professional live performances, lessons, or studio sessions.' },
  { num: '05', icon: '◉', title: 'DELIVER', desc: 'Ensure premium quality, client satisfaction, and lasting impression.' },
]

function Process() {
  return (
    <section id="process" className="bg-[#050505] py-24 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-[1fr_1fr] gap-16 items-start">
          {/* Timeline */}
          <div>
            <p className="text-red-500 text-xs tracking-widest uppercase mb-3" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
              How I Work
            </p>
            <h2
              className="text-white mb-12"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700, letterSpacing: '-0.02em' }}
            >
              WORK PROCESS
            </h2>
            <div className="relative">
              {/* Vertical line */}
              <div className="absolute left-[19px] top-0 bottom-0 w-px bg-gradient-to-b from-red-700/60 via-zinc-800 to-transparent" />
              <div className="space-y-8">
                {steps.map((step, i) => (
                  <div key={step.num} className="flex gap-6 group">
                    <div className="relative z-10 w-10 h-10 border border-red-900/60 flex items-center justify-center bg-[#050505] shrink-0 group-hover:border-red-500 group-hover:bg-red-950/30 transition-all">
                      <span className="text-red-500 text-sm">{step.icon}</span>
                    </div>
                    <div className="pt-1.5">
                      <div className="flex items-center gap-3 mb-1">
                        <span
                          className="text-red-500 text-xs"
                          style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                        >
                          {step.num}
                        </span>
                        <h3
                          className="text-white text-sm font-bold tracking-widest group-hover:text-red-400 transition-colors"
                          style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                        >
                          {step.title}
                        </h3>
                      </div>
                      <p
                        className="text-zinc-500 text-sm leading-relaxed"
                        style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                      >
                        {step.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quote card */}
          <div className="md:pt-24">
            {/* Portrait image */}
            <div className="mb-6 relative overflow-hidden" style={{ height: '220px' }}>
              <img
                src={imgPortrait}
                alt="Fidele Murengezi portrait"
                className="w-full h-full object-cover object-top"
                style={{ filter: 'grayscale(20%) contrast(1.05)' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050505]/80 via-transparent to-transparent" />
              <div className="absolute inset-0 bg-red-900/10 mix-blend-multiply" />
            </div>
            <div
              className="relative overflow-hidden p-10"
              style={{
                background: 'linear-gradient(135deg, #7f1d1d 0%, #450a0a 60%, #0a0a0a 100%)',
                border: '1px solid rgba(239,68,68,0.2)',
                boxShadow: '0 0 60px rgba(239,68,68,0.1), inset 0 0 60px rgba(0,0,0,0.4)',
              }}
            >
              {/* Glow */}
              <div className="absolute top-0 left-0 w-32 h-32 bg-red-600/20 rounded-full -translate-x-1/2 -translate-y-1/2 blur-2xl" />
              <div className="absolute bottom-0 right-0 w-24 h-24 bg-red-800/20 rounded-full translate-x-1/2 translate-y-1/2 blur-xl" />

              <div className="relative z-10">
                <span
                  className="text-red-400/60 block mb-6"
                  style={{ fontFamily: 'Rajdhani, Georgia, serif', fontSize: '64px', lineHeight: 1 }}
                >
                  "
                </span>
                <p
                  className="text-white leading-snug mb-8"
                  style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: 'clamp(20px, 3vw, 28px)', fontWeight: 700, letterSpacing: '-0.01em' }}
                >
                  Music is more than sound. It is an experience.
                </p>
                <div className="border-t border-red-800/40 pt-6">
                  <p
                    className="text-red-300/80 text-sm italic mb-6"
                    style={{ fontFamily: 'Rajdhani, Georgia, serif' }}
                  >
                    — Fidele Murengezi
                  </p>
                  <p
                    className="text-zinc-400 text-xs tracking-widest uppercase mb-5"
                    style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                  >
                    Let's create something great together.
                  </p>
                  <PrimaryBtn href="#contact">Contact Me</PrimaryBtn>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Contact ──────────────────────────────────────────────────────────────────
const contactLinks = [
  { icon: '✉', label: 'Email', value: 'murengezifidele4@gmail.com', href: 'mailto:murengezifidele4@gmail.com' },
  { icon: '◈', label: 'Instagram', value: '@fidele_the_drummer', href: 'https://instagram.com/fidele_the_drummer' },
  { icon: '☏', label: 'Phone', value: '+250 792 139 067', href: 'tel:+250792139067' },
  { icon: '◎', label: 'Location', value: 'Kigali, Rwanda', href: '#' },
]

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)
  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSent(true)
  }

  return (
    <section id="contact" className="bg-[#050505] py-24 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid md:grid-cols-[1fr_1fr] gap-16">
          {/* Left */}
          <div>
            <p className="text-red-500 text-xs tracking-widest uppercase mb-3" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
              Get in Touch
            </p>
            <h2
              className="text-white mb-4"
              style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif', fontSize: 'clamp(28px, 5vw, 56px)', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 0.95 }}
            >
              LET'S CREATE<br />
              <span className="text-red-500">SOMETHING</span><br />
              AMAZING
            </h2>
            <p
              className="text-zinc-400 text-sm leading-relaxed mb-10 max-w-sm"
              style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
            >
              Available for performances, drum lessons, piano lessons, music production, and creative collaborations.
            </p>

            <div className="grid grid-cols-1 gap-3">
              {contactLinks.map((c) => (
                <a
                  key={c.label}
                  href={c.href}
                  className="flex items-center gap-4 border border-zinc-900 hover:border-red-900/50 bg-[#0a0a0a] hover:bg-red-950/10 px-5 py-3.5 transition-all group"
                >
                  <span className="text-red-500 w-4 text-center shrink-0">{c.icon}</span>
                  <span
                    className="text-zinc-500 text-xs tracking-widest uppercase w-20 shrink-0"
                    style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
                  >
                    {c.label}
                  </span>
                  <span
                    className="text-zinc-300 text-sm group-hover:text-white transition-colors"
                    style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                  >
                    {c.value}
                  </span>
                </a>
              ))}
            </div>
          </div>

          {/* Right — form */}
          <div>
            {sent ? (
              <div
                className="border border-red-700/40 bg-red-950/20 p-10 h-full flex flex-col items-center justify-center text-center"
                style={{ boxShadow: '0 0 40px rgba(239,68,68,0.08)' }}
              >
                <div className="text-red-500 text-4xl mb-4">✓</div>
                <h3 className="text-white text-xl font-bold mb-2" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
                  Message Sent!
                </h3>
                <p className="text-zinc-500 text-sm" style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}>
                  I'll get back to you within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-xs tracking-widest uppercase text-zinc-600 mb-2" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
                    Name
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    className="w-full bg-[#0a0a0a] border border-zinc-800 focus:border-red-700 focus:outline-none px-5 py-3.5 text-white text-sm placeholder:text-zinc-700 transition-colors"
                    placeholder="Your name"
                    style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                  />
                </div>
                <div>
                  <label className="block text-xs tracking-widest uppercase text-zinc-600 mb-2" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
                    Email
                  </label>
                  <input
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                    className="w-full bg-[#0a0a0a] border border-zinc-800 focus:border-red-700 focus:outline-none px-5 py-3.5 text-white text-sm placeholder:text-zinc-700 transition-colors"
                    placeholder="your@email.com"
                    style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                  />
                </div>
                <div>
                  <label className="block text-xs tracking-widest uppercase text-zinc-600 mb-2" style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}>
                    Message
                  </label>
                  <textarea
                    required
                    rows={6}
                    value={form.message}
                    onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                    className="w-full bg-[#0a0a0a] border border-zinc-800 focus:border-red-700 focus:outline-none px-5 py-3.5 text-white text-sm placeholder:text-zinc-700 transition-colors resize-none"
                    placeholder="Tell me about your project, event, or collaboration..."
                    style={{ fontFamily: 'Rajdhani, Inter, sans-serif' }}
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <PrimaryBtn type="submit">Send Message</PrimaryBtn>
                  <GhostBtn href="#">Download Resume</GhostBtn>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="bg-[#030303] border-t border-zinc-900 py-8">
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-4">
        <span
          className="text-zinc-600 text-xs tracking-widest uppercase"
          style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
        >
          © 2026 Fidele Murengezi · All Rights Reserved
        </span>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
          <span
            className="text-red-500/70 text-xs tracking-widest uppercase"
            style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
          >
            Available for Collaborations
          </span>
        </div>
      </div>
    </footer>
  )
}

// ─── Button Components ────────────────────────────────────────────────────────
function PrimaryBtn({
  children,
  href,
  type,
}: {
  children: React.ReactNode
  href?: string
  type?: 'submit' | 'button'
}) {
  const cls =
    'inline-flex items-center gap-2 px-6 py-3 bg-red-600 text-black text-xs font-bold tracking-[0.2em] uppercase hover:bg-red-500 active:bg-red-700 transition-all duration-150 shadow-[0_0_20px_rgba(220,38,38,0.35)] hover:shadow-[0_0_30px_rgba(220,38,38,0.55)]'
  const style = { fontFamily: 'Rajdhani, League Spartan, sans-serif' }
  if (type === 'submit') {
    return (
      <button type="submit" className={cls} style={style}>
        {children}
      </button>
    )
  }
  return (
    <a href={href} className={cls} style={style}>
      {children}
    </a>
  )
}

function SecondaryBtn({ children, href }: { children: React.ReactNode; href: string }) {
  return (
    <a
      href={href}
      className="inline-flex items-center gap-2 px-6 py-3 border border-red-700 text-red-400 text-xs font-bold tracking-[0.2em] uppercase hover:bg-red-600 hover:text-black hover:border-red-600 transition-all duration-150"
      style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
    >
      {children}
    </a>
  )
}

function GhostBtn({ children, href }: { children: React.ReactNode; href: string }) {
  return (
    <a
      href={href}
      className="inline-flex items-center gap-2 px-6 py-3 border border-zinc-700 text-zinc-400 text-xs font-bold tracking-[0.2em] uppercase hover:border-zinc-500 hover:text-white transition-all duration-150"
      style={{ fontFamily: 'Rajdhani, League Spartan, sans-serif' }}
    >
      {children}
    </a>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="bg-[#050505] min-h-screen">
      <Nav />
      <Hero />
      <Projects />
      <SkillsSection />
      <Process />
      <Contact />
      <Footer />
    </div>
  )
}
